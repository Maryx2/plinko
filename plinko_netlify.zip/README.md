# Plinko Live — Netlify Edition

No Python server is required.

This version uses:
- Netlify static hosting for the game
- Netlify Functions for the API
- Netlify Blobs for persistent shared player credits and the leaderboard
- a Netlify environment variable for the admin secret

## Deploy

### Recommended: GitHub / GitLab
1. Put all files from this folder in a Git repository.
2. In Netlify, choose **Add new project → Import an existing project**.
3. Select the repository.
4. Netlify should detect `netlify.toml`. There is no build command.
5. Deploy.

### Set the admin password
In the Netlify project UI, add an environment variable:

PLINKO_ADMIN_SECRET = choose-a-strong-password

Redeploy if Netlify asks you to.

Do NOT put the admin password in index.html or commit it to Git.

## Local testing

Install Netlify CLI, then from this folder:

npm install
netlify dev

The site will be served locally with Functions and a sandboxed local Blobs store.

## Important security note

Player names are deliberately simple and do not use passwords. That is fine for a casual game, but it means a person can type another player's name and play with that account. The admin credit-grant endpoint is protected by the server-side admin secret.

If you want accounts that people can truly own, add authentication before using this publicly with anything valuable.

Credits in this project are virtual game credits only.
