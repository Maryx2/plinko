import { store, json } from "./_common.mjs";
export default async () => {
  try {
    const s = store();
    const { blobs } = await s.list({ prefix: "player/" });
    const players = [];
    for (const blob of blobs.slice(0, 250)) {
      const p = await s.get(blob.key, { type: "json", consistency: "strong" });
      if (p) players.push(p);
    }
    players.sort((a,b) => (b.credits-a.credits) || ((b.bestWin||0)-(a.bestWin||0)));
    return json({ players: players.slice(0,50) });
  } catch (e) { return json({ error: e.message, players: [] }, 500); }
};
export const config = { path: "/api/leaderboard" };
