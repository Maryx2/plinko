import { cleanName, atomicUpdate, json } from "./_common.mjs";
export default async (req) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  try {
    const body = await req.json();
    const configured = Netlify.env.get("PLINKO_ADMIN_SECRET");
    if (!configured) return json({ error: "PLINKO_ADMIN_SECRET is not configured in Netlify." }, 500);
    if (String(body.secret ?? "") !== configured) return json({ error: "Wrong admin secret." }, 403);

    const name = cleanName(body.name);
    const amount = Number(body.amount);
    if (!Number.isFinite(amount) || amount === 0 || Math.abs(amount) > 1000000) throw new Error("Invalid credit amount.");

    const player = await atomicUpdate(name, p => {
      p.credits = Math.max(0, Math.round((Number(p.credits || 0) + amount) * 100) / 100);
      return p;
    });
    return json({ player });
  } catch (e) { return json({ error: e.message }, 400); }
};
export const config = { path: "/api/admin-credits" };
