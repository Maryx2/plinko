import { cleanName, atomicUpdate, json } from "./_common.mjs";

const normal = [0.2,0.5,1,2,5,12,5,2,1,0.5,0.2];
const high   = [0,0.2,0.5,1,3,25,3,1,0.5,0.2,0];

// Approximate a Plinko distribution: sum of 10 fair left/right decisions -> slot 0..10.
function randomSlot() {
  const bytes = new Uint8Array(10);
  crypto.getRandomValues(bytes);
  let slot = 0;
  for (const b of bytes) if (b & 1) slot++;
  return slot;
}

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  try {
    const body = await req.json();
    const name = cleanName(body.name);
    const bet = Number(body.bet);
    const risk = body.risk === "high" ? "high" : "normal";
    if (!Number.isFinite(bet) || bet < 5 || bet > 500 || bet % 5 !== 0) throw new Error("Bet must be 5–500 credits in steps of 5.");

    const slot = randomSlot();
    const multiplier = (risk === "high" ? high : normal)[slot];
    const payout = Math.round(bet * multiplier * 100) / 100;

    const player = await atomicUpdate(name, p => {
      if (p.credits < bet) throw new Error("Not enough credits.");
      p.credits = Math.round((p.credits - bet + payout) * 100) / 100;
      p.bestWin = Math.max(Number(p.bestWin || 0), payout);
      p.totalWon = Math.round((Number(p.totalWon || 0) + payout) * 100) / 100;
      p.games = Number(p.games || 0) + 1;
      return p;
    });

    return json({ player, slot, multiplier, payout });
  } catch (e) { return json({ error: e.message }, 400); }
};
export const config = { path: "/api/play" };
