import { getStore } from "@netlify/blobs";

export const store = () => getStore({ name: "plinko-players", consistency: "strong" });

export function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
  });
}

export function cleanName(input) {
  const name = String(input ?? "").trim().replace(/\s+/g, " ").slice(0, 24);
  if (!name || !/^[a-zA-Z0-9 _.-]+$/.test(name)) throw new Error("Use 1–24 letters, numbers, spaces, _ . or -.");
  return name;
}

export function playerKey(name) {
  return "player/" + encodeURIComponent(name.toLowerCase());
}

export function freshPlayer(name) {
  return { name, credits: 1000, bestWin: 0, totalWon: 0, games: 0, updatedAt: Date.now() };
}

export async function getOrCreatePlayer(name) {
  const s = store();
  const key = playerKey(name);
  for (let tries = 0; tries < 5; tries++) {
    const existing = await s.get(key, { type: "json", consistency: "strong" });
    if (existing) return existing;
    const player = freshPlayer(name);
    const result = await s.setJSON(key, player, { onlyIfNew: true });
    if (result.modified) return player;
  }
  throw new Error("Could not create player. Try again.");
}

export async function atomicUpdate(name, updater) {
  const s = store();
  const key = playerKey(name);
  await getOrCreatePlayer(name);

  for (let tries = 0; tries < 8; tries++) {
    const entry = await s.getWithMetadata(key, { type: "json", consistency: "strong" });
    if (!entry) continue;
    const next = updater({ ...entry.data });
    next.updatedAt = Date.now();
    const result = await s.setJSON(key, next, { onlyIfMatch: entry.etag });
    if (result.modified) return next;
  }
  throw new Error("Player was updated at the same time. Please try again.");
}
