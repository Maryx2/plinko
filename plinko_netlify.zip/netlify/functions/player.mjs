import { cleanName, getOrCreatePlayer, json } from "./_common.mjs";
export default async (req) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  try {
    const body = await req.json();
    const name = cleanName(body.name);
    return json({ player: await getOrCreatePlayer(name) });
  } catch (e) { return json({ error: e.message }, 400); }
};
export const config = { path: "/api/player" };
