# Plinko Live — Fixed Netlify Deployment

This package is arranged specifically for a Netlify Git deployment.

## IMPORTANT

For the multiplayer credits + live leaderboard version, do NOT deploy only `public/`
and do not use a plain static-site upload.

Netlify needs the entire project so it can deploy the Functions too.

## Recommended deployment

1. Unzip this package.
2. Create a GitHub or GitLab repository.
3. Upload the CONTENTS of this folder so these are at the repository root:

   - netlify.toml
   - package.json
   - public/
   - netlify/

4. In Netlify:
   - Add new project
   - Import an existing project
   - Select your repository

5. Netlify should use:
   - Publish directory: public
   - Functions directory: netlify/functions

6. Add this environment variable in Netlify:

   PLINKO_ADMIN_SECRET = your-secret-password

7. Deploy the site.

## Why the previous deploy could show 404

The old package published from the project root. This fixed version uses a dedicated
`public/` directory containing `index.html`, which makes the publish target explicit.

## Local test

npm install
npx netlify dev

Then open the local URL shown by Netlify CLI.

## Static-only note

A drag-and-drop deployment of only the `public` folder will show the Plinko UI, but
the shared credits and leaderboard API will not work because those features require
the included Netlify Functions.

Credits are virtual game credits only.
